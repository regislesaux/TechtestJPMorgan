
import com.techtest.controler.*;
import com.techtest.model.*;
import com.techtest.view.Sales;

public class Main {

  public static void main(String[] args) {
    //Instantiate Model
    AbstractModel salesTools = new SalesModel();
    //Create Controller
    AbstractControler controler = new SalesControler(salesTools);
    //Create View
    Sales sales = new Sales(controler);
    //Add Observer
    salesTools.addObserver(sales);
  }
}