package com.techtest.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.techtest.controler.AbstractControler;

public class Sales extends JFrame implements Observer{

/**
	 * 
	 */
private static final long serialVersionUID = 1L;

//Declare requested tool for interface
private JPanel container = new JPanel();
private JTextField textField = new JTextField(20);
private List<String> logList = new ArrayList<String>();
private JLabel screen = new JLabel();
private JLabel validationMess = new JLabel();
 
//Declare variable
String messageType = "";
String messageValue = "";

//Instanciate controller
private AbstractControler controler;

//Set the window
public Sales(AbstractControler controler){                
  this.setSize(400, 300);
  this.setTitle("Sales Messages");
  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  this.setLocationRelativeTo(null);
  this.setResizable(false);
  initComposant();                
  this.controler = controler;                
  this.setContentPane(container);
  this.setVisible(true);
}

@SuppressWarnings({ "unchecked", "rawtypes" })
private void initComposant(){
  //Set the screen
  Font police = new Font("Arial", Font.BOLD, 20);
  screen = new JLabel("0");
  screen.setText("      ");
  screen.setFont(police);
  screen.setHorizontalAlignment(JLabel.RIGHT);
  screen.setPreferredSize(new Dimension(250, 100));
  
  //Create the button
  JButton validateButton = new JButton("Validate");
  validateButton.addActionListener(new ValidateListener());

  //Create and set KeyListener for the TextField
  KeyListener keyListener = new KeyListener() {
	public void keyPressed(KeyEvent keyEvent) {
        printIt("Pressed", keyEvent);
      }
    public void keyReleased(KeyEvent keyEvent) {
        printIt("Released", keyEvent);
        messageValue = textField.getText();
        validateButton.setName(messageType+"-"+messageValue);
      }
    public void keyTyped(KeyEvent keyEvent) {
        printIt("Typed", keyEvent);
      }
    private void printIt(String title, KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        String keyText = KeyEvent.getKeyText(keyCode);
        System.out.println(title + " : " + keyText + " / " + keyEvent.getKeyChar());
      }
      
    };
  textField.addKeyListener(keyListener);
  
  //Create and set the comboBox
  String[] messageTypes = { "","Product Type 1", "Product Type 2", "Product Type 3"};
  JComboBox<?> messageTypesList = new JComboBox(messageTypes);
  messageTypesList.addActionListener(new ActionListener(){
	  public void actionPerformed(ActionEvent e){
    	  JComboBox<?> messageList = (JComboBox<?>)e.getSource();
          messageType = (String)messageList.getSelectedItem();
          validateButton.setName(messageType+"-"+messageValue);
      }
  });

  //Create and set the Middle Top Panel
  JPanel panelMidTop = new JPanel();
  panelMidTop.setLayout(new GridLayout(1, 2));
  panelMidTop.setPreferredSize(new Dimension(250, 30));
  panelMidTop.add(messageTypesList);
  panelMidTop.add(textField);
  
  //Create and set the Middle Bottom Panel
  JPanel panelMidBottom = new JPanel();
  panelMidBottom.add(validateButton);
  panelMidBottom.setPreferredSize(new Dimension(350, 60));
  
  //Create and set the Top Panel
  JPanel panelTop = new JPanel();
  panelTop.setPreferredSize(new Dimension(350, 100));
  panelTop.add(screen);
  panelTop.setBorder(BorderFactory.createLineBorder(Color.black));
  
  //Create and set the Bottom Panel
  JPanel panelBottom = new JPanel();
  panelBottom.setPreferredSize(new Dimension(350, 100));
  panelBottom.add(validationMess, BorderLayout.CENTER);

  //Add all panel to the container
  container.add(panelTop, BorderLayout.NORTH);
  container.add(panelMidTop, BorderLayout.CENTER);
  container.add(panelMidBottom, BorderLayout.CENTER);
  container.add(panelBottom, BorderLayout.SOUTH);
}   


class ValidateListener implements ActionListener{ 
	
@Override
public void actionPerformed(ActionEvent e) {
	controler.setValue(((JButton)e.getSource()).getName());
}
	}

@Override
public void update(Observable o, Object arg) {
	int listSize = this.logList.size()+1;
	  screen.setText(arg.toString());
	  
	  //Verify the number of sales and display validation message
	  if(listSize <= 10){
		  validationMess.setForeground(Color.GREEN);
		  validationMess.setText(listSize+" added in list");
		  this.logList.add(listSize+" - "+arg);
	  }else{
		  validationMess.setForeground(Color.RED);
		  for(@SuppressWarnings("unused") String element : this.logList){
		  }
		  validationMess.setPreferredSize(new Dimension(390, 200));
		  validationMess.setText("List full "+this.logList.get(this.logList.size()));
		
	  }
}
}
