package com.techtest.controler;

import com.techtest.model.AbstractModel;

public class SalesControler extends AbstractControler {

  //Controller constructor
  public SalesControler(AbstractModel cal) {
    super(cal);
  }

  //Method to display input
  public void control() {
	  this.salesTools.calcul(this.value);
  }
}