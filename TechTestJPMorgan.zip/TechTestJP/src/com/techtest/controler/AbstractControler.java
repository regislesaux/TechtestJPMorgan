package com.techtest.controler;
import java.util.ArrayList;
import com.techtest.model.AbstractModel;

public abstract class AbstractControler {

  protected AbstractModel salesTools;
  protected String value ="";
  protected ArrayList<String> listOperateur = new ArrayList<String>();

  public AbstractControler(AbstractModel cal){
    this.salesTools = cal;
   }
   
  public void setValue(String value){
    this.value = value;
    this.salesTools.calcul(this.value);
  }
  
}