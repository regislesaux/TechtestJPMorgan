package com.techtest.model;

public class SalesModel extends AbstractModel{

  // Methods to modify the model
  public void setValue(String result){
	  System.out.println("setValue = "+result);
    this.value = result;
    notifyObserver(this.value);
  }
  public void calcul(String value){
    notifyObserver(value);
  }


}