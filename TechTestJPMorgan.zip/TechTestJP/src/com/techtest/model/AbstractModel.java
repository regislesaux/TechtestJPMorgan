package com.techtest.model;

import java.util.ArrayList;
import java.util.Observer;
import com.techtest.observer.Observable;

public abstract class AbstractModel implements Observable{

  protected double result = 0;   
  protected String value = "";
  private ArrayList<Observer> listObserver = new ArrayList<Observer>();   
  

  
  public abstract void calcul(String value);
  public abstract void setValue(String value) ;

  //Add an Observer
  public void addObserver(Observer obs) {
    this.listObserver.add(obs);
  }
  
  //Notify all observer
  public void notifyObserver(String str) {
	  System.out.println("notifyObserver = "+str);
    for(Observer obs : listObserver)
      obs.update(null, str);
  }

  public void removeObserver() {
    listObserver = new ArrayList<Observer>();
  }  
}