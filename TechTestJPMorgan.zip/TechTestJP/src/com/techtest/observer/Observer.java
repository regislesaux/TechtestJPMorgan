package com.techtest.observer;

public interface Observer {
  public void update(String str);
}
